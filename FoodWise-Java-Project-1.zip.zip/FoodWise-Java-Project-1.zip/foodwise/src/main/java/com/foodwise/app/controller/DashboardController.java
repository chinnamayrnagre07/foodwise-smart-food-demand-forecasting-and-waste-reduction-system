package com.foodwise.app.controller;

import com.foodwise.app.model.MealRecord;
import com.foodwise.app.repository.MealRecordRepository;
import com.foodwise.app.service.ForecastService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

@Controller
public class DashboardController {
    private final MealRecordRepository repository;
    private final ForecastService forecastService;
    public DashboardController(MealRecordRepository repository, ForecastService forecastService) {
        this.repository = repository; this.forecastService = forecastService;
    }

    @GetMapping("/")
    public String dashboard(Model model) {
        List<MealRecord> records = repository.findAllByOrderByRecordDateDesc();
        int prepared = records.stream().mapToInt(MealRecord::getPrepared).sum();
        int sold = records.stream().mapToInt(MealRecord::getSold).sum();
        int leftovers = records.stream().mapToInt(MealRecord::getLeftovers).sum();
        double wastePercent = prepared == 0 ? 0 : leftovers * 100.0 / prepared;
        double mae = forecastService.meanAbsoluteErrorOnRecentData();
        model.addAttribute("records", records);
        model.addAttribute("newRecord", new MealRecord(LocalDate.now(), 0, 0, ""));
        model.addAttribute("recordCount", records.size());
        model.addAttribute("totalPrepared", prepared);
        model.addAttribute("totalSold", sold);
        model.addAttribute("totalLeftovers", leftovers);
        model.addAttribute("wastePercent", wastePercent);
        model.addAttribute("predictedDemand", forecastService.predictNextDayDemand());
        model.addAttribute("recommendedPreparation", forecastService.recommendedPreparation());
        model.addAttribute("mae", mae);
        // Chart.js reads chronological data, while the table is newest-first.
        List<MealRecord> chartRows = new ArrayList<>(records.stream().limit(14).toList());
        Collections.reverse(chartRows);
        model.addAttribute("chartLabels", chartRows.stream().map(r -> r.getRecordDate().toString()).toList());
        model.addAttribute("chartSold", chartRows.stream().map(MealRecord::getSold).toList());
        model.addAttribute("chartLeftovers", chartRows.stream().map(MealRecord::getLeftovers).toList());
        return "dashboard";
    }

    @PostMapping("/records")
    public String addRecord(@Valid @ModelAttribute("newRecord") MealRecord record,
                            BindingResult result, RedirectAttributes redirect) {
        if (record.getPrepared() != null && record.getSold() != null && record.getSold() > record.getPrepared()) {
            result.rejectValue("sold", "invalid.sold", "Sold meals cannot exceed meals prepared.");
        }
        if (record.getRecordDate() != null && repository.existsByRecordDate(record.getRecordDate())) {
            result.rejectValue("recordDate", "duplicate.date", "A record already exists for this date. Delete it first to replace it.");
        }
        if (result.hasErrors()) {
            redirect.addFlashAttribute("error", result.getAllErrors().get(0).getDefaultMessage());
            return "redirect:/#record-form";
        }
        repository.save(record);
        redirect.addFlashAttribute("success", "Daily meal record saved.");
        return "redirect:/";
    }

    @PostMapping("/records/{id}/delete")
    public String deleteRecord(@PathVariable Long id, RedirectAttributes redirect) {
        if (repository.existsById(id)) repository.deleteById(id);
        redirect.addFlashAttribute("success", "Record deleted.");
        return "redirect:/";
    }
}
