package com.foodwise.app.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;

@Entity
@Table(name = "meal_records", uniqueConstraints = @UniqueConstraint(columnNames = "record_date"))
public class MealRecord {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "Please choose a date")
    @Column(name = "record_date", nullable = false, unique = true)
    private LocalDate recordDate;

    @NotNull @Min(value = 0, message = "Prepared count cannot be negative")
    @Column(nullable = false)
    private Integer prepared;

    @NotNull @Min(value = 0, message = "Sold count cannot be negative")
    @Column(nullable = false)
    private Integer sold;

    @Column(length = 500)
    private String notes;

    public MealRecord() {}
    public MealRecord(LocalDate recordDate, Integer prepared, Integer sold, String notes) {
        this.recordDate = recordDate; this.prepared = prepared; this.sold = sold; this.notes = notes;
    }
    public Long getId() { return id; }
    public LocalDate getRecordDate() { return recordDate; }
    public void setRecordDate(LocalDate recordDate) { this.recordDate = recordDate; }
    public Integer getPrepared() { return prepared; }
    public void setPrepared(Integer prepared) { this.prepared = prepared; }
    public Integer getSold() { return sold; }
    public void setSold(Integer sold) { this.sold = sold; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
    public int getLeftovers() { return Math.max(0, prepared - sold); }
    public double getWastePercent() { return prepared == 0 ? 0.0 : getLeftovers() * 100.0 / prepared; }
}
