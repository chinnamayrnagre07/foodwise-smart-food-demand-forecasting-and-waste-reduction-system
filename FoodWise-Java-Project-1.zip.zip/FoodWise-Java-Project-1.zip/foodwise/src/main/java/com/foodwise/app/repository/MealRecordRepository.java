package com.foodwise.app.repository;

import com.foodwise.app.model.MealRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.List;

public interface MealRecordRepository extends JpaRepository<MealRecord, Long> {
    List<MealRecord> findAllByOrderByRecordDateDesc();
    List<MealRecord> findTop7ByOrderByRecordDateDesc();
    boolean existsByRecordDate(LocalDate recordDate);
}
