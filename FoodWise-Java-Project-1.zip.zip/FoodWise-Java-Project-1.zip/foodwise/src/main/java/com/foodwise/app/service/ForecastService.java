package com.foodwise.app.service;

import com.foodwise.app.model.MealRecord;
import com.foodwise.app.repository.MealRecordRepository;
import org.springframework.stereotype.Service;
import java.util.Collections;
import java.util.List;

@Service
public class ForecastService {
    private final MealRecordRepository repository;
    public ForecastService(MealRecordRepository repository) { this.repository = repository; }

    // Baseline forecast: mean of the latest seven recorded daily sales values.
    public int predictNextDayDemand() {
        List<MealRecord> recent = repository.findTop7ByOrderByRecordDateDesc();
        if (recent.isEmpty()) return 0;
        double mean = recent.stream().mapToInt(MealRecord::getSold).average().orElse(0);
        return (int) Math.round(mean);
    }

    public int recommendedPreparation() {
        // Add a modest 5% buffer to predicted demand; keep the rule transparent.
        return (int) Math.ceil(predictNextDayDemand() * 1.05);
    }

    public double meanAbsoluteErrorOnRecentData() {
        List<MealRecord> rows = repository.findAllByOrderByRecordDateDesc();
        Collections.reverse(rows);
        if (rows.size() < 3) return -1;
        double totalError = 0;
        int evaluated = 0;
        // Walk forward: each prediction only uses records that occurred before the target date.
        for (int i = 2; i < rows.size(); i++) {
            int start = Math.max(0, i - 7);
            double mean = rows.subList(start, i).stream().mapToInt(MealRecord::getSold).average().orElse(0);
            totalError += Math.abs(rows.get(i).getSold() - mean);
            evaluated++;
        }
        return evaluated == 0 ? -1 : totalError / evaluated;
    }
}
