CREATE DATABASE IF NOT EXISTS foodwise;
USE foodwise;
CREATE TABLE IF NOT EXISTS meal_records (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  record_date DATE NOT NULL UNIQUE,
  prepared INT NOT NULL CHECK (prepared >= 0),
  sold INT NOT NULL CHECK (sold >= 0 AND sold <= prepared),
  notes VARCHAR(500)
);
